(function($){
  $(document)
    .ready(function(){
      // (jQuery Coder Here)
  });
}(jQuery));
